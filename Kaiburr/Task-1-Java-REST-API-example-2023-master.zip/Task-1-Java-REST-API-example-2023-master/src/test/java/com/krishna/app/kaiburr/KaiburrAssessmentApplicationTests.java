package com.krishna.app.kaiburr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaiburrAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
